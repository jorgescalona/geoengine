.. OpenERP GeoEngine documentation master file, created by
   sphinx-quickstart on Mon Mar  5 09:15:25 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to OpenERP GeoEngine's documentation!
=============================================

Contents:

.. toctree::
   :maxdepth: 2
   
   what_is_geoengine
   prerequisite
   installation
   postgisify
   api_doc

   How to use GeoEngine
   Modules presentations
   API presentation
   Manage your layer from client
   Create a geocolumn from client
   

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

